%%%%%% image compressed sensing using hadamard random measurement matrix
%%%%%% with selecting m according to coffecient of signal. solve by l1 minimization
%%here we are not taking taking measurements of full signal......skiping
%%some coefficients (14) and 22 for measurements. If we do not normalize masurement matrix then embedding capasity is more
clc;
clear;
close all;
clear all
clc;
path(path, 'D:\IIT INDORE\phd data\matlab-toolboxes-master\toolbox_sparsity');
path(path, 'D:\IIT INDORE\phd data\compressed sensing\matlab code\CoSaMP_OMP');
path(path, 'D:\Document related to B.Tech and M.tech\Document related to M.Tech\Matlab_code_M.tech_2\Images result\Test images');
cover = input('Enter color cover image: ', 's');
x=imread(cover);
x1_red=x(:,:,1);
x1_green=x(:,:,2);
x1_blue=x(:,:,3);
figure,imshow(x),title('Original Image');

%save fn1 x;
blk=8; % image is decomposed using 8x8 blocks

[row col]=size(x1_red);
%order=[1 9 2 3 10 17 25 18 11 4 5 12 19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];
order_not_embed = [1 9 2 3 10 17 25 18 11 4 5 12 19 26]; % taking 12 coeffieints which as taken as these are
order_can_embed = [33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];
%order=[33 41 49 57 26 34 42 50 19 27 35 43 12 20 28 36 5 13 21 29 6 14 22 7 15 8];
k1=size(order_not_embed);
k1=k1(2);
k2=size(order_can_embed);
k2=k2(2);
fun1=@dct2;
fun2=@idct2;
%%%%%%%%%%%%%%%%%%%%%% block wise sparsification %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%% red %%%%
J_red = blkproc(x1_red,[blk blk],fun1);
x1_red=im2col(J_red,[blk blk],'distinct');  % taking blk x blk matrix as column.....
x1_red_not_embed = x1_red(order_not_embed,:);
x1_red_can_embed = x1_red(order_can_embed,:);
        %%%% green %%%%
J_green = blkproc(x1_green,[blk blk],fun1);
x1_green=im2col(J_green,[blk blk],'distinct');  % taking blk x blk matrix as column.....
x1_green_not_embed = x1_green(order_not_embed,:);
x1_green_can_embed = x1_green(order_can_embed,:);
        %%%% blue %%%%
J_blue = blkproc(x1_blue,[blk blk],fun1);
x1_blue=im2col(J_blue,[blk blk],'distinct');  % taking blk x blk matrix as column.....
x1_blue_not_embed = x1_blue(order_not_embed,:);
x1_blue_can_embed = x1_blue(order_can_embed,:);
% x1=x1'; 
%n=blk*blk;
% n=blk*blk - size(order_not_embed);      % or n is size of x1_can_embed
% n=n(2);
% %m=n/4;      % numner of measurements
n=k2;
%A = hadamard(n);    % for hadamard n must be an integer and n, n/12 or n/20 must be a power of 2.
A = hadamard(blk*blk);
%A=rand(blk*blk);
p = randperm(blk*blk,n);
A = A(:,p);
%A_normalize=normc(A);

% index for measurement matrix
%{
for i=1:blk/2           %for m=n/4
    for j=1:blk/2
        index(j+(i-1)*blk/2)=j+(i-1)*blk;
    end
end
%}
% measurement matrix index it is coefficceints index which are part of zizzag scan order of x1_can_embed
index=[1 2 3 4 5 6 7 8 9 10 12 13 14 15 18 19 20 21 25 26 27 28]; % from x1_can_embed (taking 22)
%index=[1 2 3 4 5 6 7 8 9 10 12 13 14 15 18 19 20 21 25 26 27 28 33 34 35]; % from x1_can_embed (taking 25)
%index=[1 2 3 4 5 6 7 8 9 10 12 13 14 15 18 19 20 21 25 26 27 28 33 34 35 41 42 57]; % from x1_can_embed (taking 28)

m=size(index);
m=m(2);
%%%%% updating measurement matrix
A2=A(index,:);      % size m x n (m<n)
A2_normalize=normc(A2);
A2_normalize=A2;

%%%% fiinding measurements y=A*x
for i=1:(row*col)/(blk*blk)
    y1_red(:,i)=A2_normalize*x1_red_can_embed(:,i);
    y1_green(:,i)=A2_normalize*x1_green_can_embed(:,i);
    y1_blue(:,i)=A2_normalize*x1_blue_can_embed(:,i);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% embedding 
%%%%%%% quantize y to int8 y=y/20; then y2=int8(y)
y2_red=int8(y1_red);
y2_red=y2_red';
y2_green=int8(y1_green);
y2_green=y2_green';
y2_blue=int8(y1_blue);
y2_blue=y2_blue';
 %%%%%%%%%%%%%%%% count message capacity
 count_red=0;
 count_green=0;
 count_blue=0;
for i=1:(row*col)/(blk*blk)
    for j=1:m      % number of measurements
        if y2_red(i,j)== -1 || y2_red(i,j)== 0 || y2_red(i,j)==1
            continue;
        else
           count_red=count_red+1; 
        end
        if y2_green(i,j)== -1 || y2_green(i,j)== 0 || y2_green(i,j)==1
            continue;
        else
           count_green=count_green+1; 
        end
        if y2_blue(i,j)== -1 || y2_blue(i,j)== 0 || y2_blue(i,j)==1
            continue;
        else
           count_blue=count_blue+1; 
        end
    end
end

%----------------------Message Generation--------------
d_red=rand(1,count_red*2);
dd_red=find(d_red>.5);                     % run command whos str1 ..problem is size of str1 is very large
str1_red=zeros(1,count_red*2);
str1_red(dd_red)=1;
 
d_green=rand(1,count_green*2);
dd_green=find(d_green>.5);                     % run command whos str1 ..problem is size of str1 is very large
str1_green=zeros(1,count_green*2);
str1_green(dd_green)=1;

d_blue=rand(1,count_blue*2);
dd_blue=find(d_blue>.5);                     % run command whos str1 ..problem is size of str1 is very large
str1_blue=zeros(1,count_blue*2);
str1_blue(dd_blue)=1;

% c=input('enter the message ','s');
% d=uint8(c);
% str=dec2bin(d,7);
% [r1 c1]=size(str);
% str1=im2col(str',[c1 r1],'distinct');
% str1=str1';

%order_can_embed = [11 4 5 12 19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];

% embedding order....we can embed in random order or in sequential order or
% in zizzag scan order (it is position of order_can_embed in
% x1_can_embed)...not required becoz we have only m measurements in which
% we are embedding
%order_embed = [6 1 2 7 12 18 25 33 26 19 13 8 3 4 9 14 20 27 34 41 49 42 35 28 21 15 1 5];
%order_embed = randperm(m);      % took random embedding index
order_embed = [1:m];      % took random embedding index
aa_red=y2_red;
aa_green=y2_green;
aa_blue=y2_blue;
k_red=1;
k_green=1;
k_blue=1;
for i=1:(row*col)/(blk*blk)
    for j=1:m                        
        %%%%%%%%%%%%%%% for RED %%%%%%%%%%%%%%%%%%%
        if aa_red(i,order_embed(1,j))==-1 || aa_red(i,order_embed(1,j))== 0 || aa_red(i,order_embed(1,j))==1
            continue;
        else
        if mod(aa_red(i,order_embed(1,j)),2)==0
            if mod(aa_red(i,order_embed(1,j)),4)==0
                if (k_red+1)<count_red*2&&str1_red(1,k_red)==0&&str1_red(1,k_red+1)==0
                    aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))+1;
                    k_red=k_red+2;   
                elseif((k_red+1)<count_red*2&&str1_red(1,k_red)==0&&str1_red(1,k_red+1)==1)
                     aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))-1;
                    k_red=k_red+2;
                elseif ((k_red+1)<count_red*2&&str1_red(1,k_red)==1&&str1_red(1,k_red+1)==0)
                     aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j));
                    k_red=k_red+2;
                elseif ((k_red+1)<count_red*2&&str1_red(1,k_red)==1&&str1_red(1,k_red+1)==1)
                     aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))+2;
                    k_red=k_red+2;
                end     
            else
                if((k_red+1)<count_red*2&&str1_red(1,k_red)==0&&str1_red(1,k_red+1)==0)
                    if (aa_red(i,order_embed(1,j))~=2)
                        aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))-1;
                    else
                        aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))+3;
                    end
                    k_red=k_red+2;
                elseif((k_red+1)<count_red*2&&str1_red(1,k_red)==0&&str1_red(1,k_red+1)==1)
                     if (aa_red(i,order_embed(1,j))~=-2)
                        aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))+1;
                    else
                        aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))-3;
                    end
                    k_red=k_red+2;
                elseif ((k_red+1)<count_red*2&&str1_red(1,k_red)==1&&str1_red(1,k_red+1)==0)
                     if (aa_red(i,order_embed(1,j))~=-2)
                        aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))+2;
                    else
                        aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))-2;
                    end
                    k_red=k_red+2;
                elseif ((k_red+1)<count_red*2&&str1_red(1,k_red)==1&&str1_red(1,k_red+1)==1)
                     aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j));
                    k_red=k_red+2;
                end  
            end
        else
%             %if mod(aa(i,order_embed(1,j))-1,2)==0
                if mod(aa_red(i,order_embed(1,j))-1,4)==0
                    if((k_red+1)<count_red*2&&str1_red(1,k_red)==0&&str1_red(1,k_red+1)==0)
                     aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j));
                    k_red=k_red+2;   
                    elseif((k_red+1)<count_red*2&&str1_red(1,k_red)==0&&str1_red(1,k_red+1)==1)
                     aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))-2;
                    k_red=k_red+2;
                    elseif ((k_red+1)<count_red*2&&str1_red(1,k_red)==1&&str1_red(1,k_red+1)==0)
                     aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))-1;
                    k_red=k_red+2;
                    elseif ((k_red+1)<count_red*2&&str1_red(1,k_red)==1&&str1_red(1,k_red+1)==1)
                    aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))+1;
                    k_red=k_red+2;
                    end     
                else
                     if((k_red+1)<count_red*2&&str1_red(1,k_red)==0&&str1_red(1,k_red+1)==0)
                     aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))+2;
                    k_red=k_red+2;
                    elseif((k_red+1)<(count_red*2)&&str1_red(1,k_red)==0&&str1_red(1,k_red+1)==1)
                     aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j));
                    k_red=k_red+2;
                     elseif ((k_red+1)<count_red*2&&str1_red(1,k_red)==1&&str1_red(1,k_red+1)==0)
                     aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))+1;
                    k_red=k_red+2;
                    elseif ((k_red+1)<count_red*2&&str1_red(1,k_red)==1&&str1_red(1,k_red+1)==1)
                     aa_red(i,order_embed(1,j))=aa_red(i,order_embed(1,j))-1;
                    k_red=k_red+2;
                    end  
                end          
                
            %end
        end
        end
        
        %%%%%%%%%%%%%%% for Green %%%%%%%%%%%%%%%%%%%
        if aa_green(i,order_embed(1,j))==-1 || aa_green(i,order_embed(1,j))== 0 || aa_green(i,order_embed(1,j))==1
            continue;
        else
        if mod(aa_green(i,order_embed(1,j)),2)==0
            if mod(aa_green(i,order_embed(1,j)),4)==0
                if (k_green+1)<count_green*2&&str1_green(1,k_green)==0&&str1_green(1,k_green+1)==0
                    aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))+1;
                    k_green=k_green+2;   
                elseif((k_green+1)<count_green*2&&str1_green(1,k_green)==0&&str1_green(1,k_green+1)==1)
                     aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))-1;
                    k_green=k_green+2;
                elseif ((k_green+1)<count_green*2&&str1_green(1,k_green)==1&&str1_green(1,k_green+1)==0)
                     aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j));
                    k_green=k_green+2;
                elseif ((k_green+1)<count_green*2&&str1_green(1,k_green)==1&&str1_green(1,k_green+1)==1)
                     aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))+2;
                    k_green=k_green+2;
                end     
            else
                if((k_green+1)<count_green*2&&str1_green(1,k_green)==0&&str1_green(1,k_green+1)==0)
                    if (aa_green(i,order_embed(1,j))~=2)
                        aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))-1;
                    else
                        aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))+3;
                    end
                    k_green=k_green+2;
                elseif((k_green+1)<count_green*2&&str1_green(1,k_green)==0&&str1_green(1,k_green+1)==1)
                     if (aa_green(i,order_embed(1,j))~=-2)
                        aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))+1;
                    else
                        aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))-3;
                    end
                    k_green=k_green+2;
                elseif ((k_green+1)<count_green*2&&str1_green(1,k_green)==1&&str1_green(1,k_green+1)==0)
                     if (aa_green(i,order_embed(1,j))~=-2)
                        aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))+2;
                    else
                        aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))-2;
                    end
                    k_green=k_green+2;
                elseif ((k_green+1)<count_green*2&&str1_green(1,k_green)==1&&str1_green(1,k_green+1)==1)
                     aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j));
                    k_green=k_green+2;
                end  
            end
        else
%             %if mod(aa(i,order_embed(1,j))-1,2)==0
                if mod(aa_green(i,order_embed(1,j))-1,4)==0
                    if((k_green+1)<count_green*2&&str1_green(1,k_green)==0&&str1_green(1,k_green+1)==0)
                     aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j));
                    k_green=k_green+2;   
                    elseif((k_green+1)<count_green*2&&str1_green(1,k_green)==0&&str1_green(1,k_green+1)==1)
                     aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))-2;
                    k_green=k_green+2;
                    elseif ((k_green+1)<count_green*2&&str1_green(1,k_green)==1&&str1_green(1,k_green+1)==0)
                     aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))-1;
                    k_green=k_green+2;
                    elseif ((k_green+1)<count_green*2&&str1_green(1,k_green)==1&&str1_green(1,k_green+1)==1)
                    aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))+1;
                    k_green=k_green+2;
                    end     
                else
                     if((k_green+1)<count_green*2&&str1_green(1,k_green)==0&&str1_green(1,k_green+1)==0)
                     aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))+2;
                    k_green=k_green+2;
                    elseif((k_green+1)<(count_green*2)&&str1_green(1,k_green)==0&&str1_green(1,k_green+1)==1)
                     aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j));
                    k_green=k_green+2;
                     elseif ((k_green+1)<count_green*2&&str1_green(1,k_green)==1&&str1_green(1,k_green+1)==0)
                     aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))+1;
                    k_green=k_green+2;
                    elseif ((k_green+1)<count_green*2&&str1_green(1,k_green)==1&&str1_green(1,k_green+1)==1)
                     aa_green(i,order_embed(1,j))=aa_green(i,order_embed(1,j))-1;
                    k_green=k_green+2;
                    end  
                end          
                
            %end
        end
        end
        %%%%%%%%%%%%%%% for Blue %%%%%%%%%%%%%%%%%%%
        if aa_blue(i,order_embed(1,j))==-1 || aa_blue(i,order_embed(1,j))== 0 || aa_blue(i,order_embed(1,j))==1
            continue;
        else
        if mod(aa_blue(i,order_embed(1,j)),2)==0
            if mod(aa_blue(i,order_embed(1,j)),4)==0
                if (k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==0&&str1_blue(1,k_blue+1)==0
                    aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))+1;
                    k_blue=k_blue+2;   
                elseif((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==0&&str1_blue(1,k_blue+1)==1)
                     aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))-1;
                    k_blue=k_blue+2;
                elseif ((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==1&&str1_blue(1,k_blue+1)==0)
                     aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j));
                    k_blue=k_blue+2;
                elseif ((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==1&&str1_blue(1,k_blue+1)==1)
                     aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))+2;
                    k_blue=k_blue+2;
                end     
            else
                if((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==0&&str1_blue(1,k_blue+1)==0)
                    if (aa_blue(i,order_embed(1,j))~=2)
                        aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))-1;
                    else
                        aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))+3;
                    end
                    k_blue=k_blue+2;
                elseif((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==0&&str1_blue(1,k_blue+1)==1)
                     if (aa_blue(i,order_embed(1,j))~=-2)
                        aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))+1;
                    else
                        aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))-3;
                    end
                    k_blue=k_blue+2;
                elseif ((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==1&&str1_blue(1,k_blue+1)==0)
                     if (aa_blue(i,order_embed(1,j))~=-2)
                        aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))+2;
                    else
                        aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))-2;
                    end
                    k_blue=k_blue+2;
                elseif ((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==1&&str1_blue(1,k_blue+1)==1)
                     aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j));
                    k_blue=k_blue+2;
                end  
            end
        else
%             %if mod(aa(i,order_embed(1,j))-1,2)==0
                if mod(aa_blue(i,order_embed(1,j))-1,4)==0
                    if((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==0&&str1_blue(1,k_blue+1)==0)
                     aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j));
                    k_blue=k_blue+2;   
                    elseif((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==0&&str1_blue(1,k_blue+1)==1)
                     aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))-2;
                    k_blue=k_blue+2;
                    elseif ((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==1&&str1_blue(1,k_blue+1)==0)
                     aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))-1;
                    k_blue=k_blue+2;
                    elseif ((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==1&&str1_blue(1,k_blue+1)==1)
                    aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))+1;
                    k_blue=k_blue+2;
                    end     
                else
                     if((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==0&&str1_blue(1,k_blue+1)==0)
                     aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))+2;
                    k_blue=k_blue+2;
                    elseif((k_blue+1)<(count_blue*2)&&str1_blue(1,k_blue)==0&&str1_blue(1,k_blue+1)==1)
                     aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j));
                    k_blue=k_blue+2;
                     elseif ((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==1&&str1_blue(1,k_blue+1)==0)
                     aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))+1;
                    k_blue=k_blue+2;
                    elseif ((k_blue+1)<count_blue*2&&str1_blue(1,k_blue)==1&&str1_blue(1,k_blue+1)==1)
                     aa_blue(i,order_embed(1,j))=aa_blue(i,order_embed(1,j))-1;
                    k_blue=k_blue+2;
                    end  
                end          
                
            %end
        end
        end
    end
end
save fn2 aa_red;

%%%%%%%%%%%%%%%%%%%%%%% Message recovery (extraction) check %%%%%%%%%%%%%%%%%%%%
str1_red_recover=zeros(1,count_red*2);
str1_green_recover=zeros(1,count_green*2);
str1_blue_recover=zeros(1,count_blue*2);
k2_red=1;
k2_green=1;
k2_blue=1;
for i=1:(row*col)/(blk*blk)
    for j=1:m  
        %%%%%%%%%%%%%%%% for RED %%%%%%%%%%%%%%
        if aa_red(i,order_embed(1,j))==-1 || aa_red(i,order_embed(1,j))== 0 || aa_red(i,order_embed(1,j))==1
            continue;
        else
            if mod(aa_red(i,order_embed(1,j)),2)==0
              if mod(aa_red(i,order_embed(1,j)),4)==0
                  str1_red_recover(1,k2_red)=1;
                  str1_red_recover(1,k2_red+1)=0;
                  k2_red=k2_red+2;
              else
                  str1_red_recover(1,k2_red)=1;
                  str1_red_recover(1,k2_red+1)=1;
                  k2_red=k2_red+2;
              end
            else
                %if mod(aa(i,order_embed(1,j))-1,2)==0
                 if mod(aa_red(i,order_embed(1,j))-1,4)==0
                    str1_red_recover(1,k2_red)=0;
                    str1_red_recover(1,k2_red+1)=0;
                    k2_red=k2_red+2;
                 else
                    str1_red_recover(1,k2_red)=0;
                    str1_red_recover(1,k2_red+1)=1;
                    k2_red=k2_red+2;
                 end
                %end
            end           
        end
         %%%%%%%%%%%%%%%% for Green %%%%%%%%%%%%%%
        if aa_green(i,order_embed(1,j))==-1 || aa_green(i,order_embed(1,j))== 0 || aa_green(i,order_embed(1,j))==1
            continue;
        else
            if mod(aa_green(i,order_embed(1,j)),2)==0
              if mod(aa_green(i,order_embed(1,j)),4)==0
                  str1_green_recover(1,k2_green)=1;
                  str1_green_recover(1,k2_green+1)=0;
                  k2_green=k2_green+2;
              else
                  str1_green_recover(1,k2_green)=1;
                  str1_green_recover(1,k2_green+1)=1;
                  k2_green=k2_green+2;
              end
            else
                %if mod(aa(i,order_embed(1,j))-1,2)==0
                 if mod(aa_green(i,order_embed(1,j))-1,4)==0
                    str1_green_recover(1,k2_green)=0;
                    str1_green_recover(1,k2_green+1)=0;
                    k2_green=k2_green+2;
                 else
                    str1_green_recover(1,k2_green)=0;
                    str1_green_recover(1,k2_green+1)=1;
                    k2_green=k2_green+2;
                 end
                %end
            end           
        end
         %%%%%%%%%%%%%%%% for BLUE %%%%%%%%%%%%%%
        if aa_blue(i,order_embed(1,j))==-1 || aa_blue(i,order_embed(1,j))== 0 || aa_blue(i,order_embed(1,j))==1
            continue;
        else
            if mod(aa_blue(i,order_embed(1,j)),2)==0
              if mod(aa_blue(i,order_embed(1,j)),4)==0
                  str1_blue_recover(1,k2_blue)=1;
                  str1_blue_recover(1,k2_blue+1)=0;
                  k2_blue=k2_blue+2;
              else
                  str1_blue_recover(1,k2_blue)=1;
                  str1_blue_recover(1,k2_blue+1)=1;
                  k2_blue=k2_blue+2;
              end
            else
                %if mod(aa(i,order_embed(1,j))-1,2)==0
                 if mod(aa_blue(i,order_embed(1,j))-1,4)==0
                    str1_blue_recover(1,k2_blue)=0;
                    str1_blue_recover(1,k2_blue+1)=0;
                    k2_blue=k2_blue+2;
                 else
                    str1_blue_recover(1,k2_blue)=0;
                    str1_blue_recover(1,k2_blue+1)=1;
                    k2_blue=k2_blue+2;
                 end
                %end
            end           
        end
    end
end
Error_message_red=str1_red(1,:)-str1_red_recover(1,:);
Error_message_green=str1_green(1,:)-str1_green_recover(1,:);
Error_message_blue=str1_blue(1,:)-str1_blue_recover(1,:);
save Error_CS_steg7_7_red Error_message_red;
save Error_CS_steg7_7_green Error_message_green;
save Error_CS_steg7_7_blue Error_message_blue;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
b_red=double(aa_red);           % b is measurements with message embedded 4096xm
b_red=b_red';                   % mx4096
b_green=double(aa_green);           % b is measurements with message embedded 4096xm
b_green=b_green';                   % mx4096
b_blue=double(aa_blue);           % b is measurements with message embedded 4096xm
b_blue=b_blue';                   % mx4096

%%%% combined measurement i.e. concatination of 'x1_not_embed' and 'b'
y_update_red = zeros(m+k1, (row*col)/(blk*blk)); % k1 is size of order_not_embed
y_update_green = zeros(m+k1, (row*col)/(blk*blk)); % k1 is size of order_not_embed
y_update_blue = zeros(m+k1, (row*col)/(blk*blk)); % k1 is size of order_not_embed
%y_update(order_not_embed,:)=x1(order_not_embed,:);
y_update_red = [x1_red_not_embed; b_red];   % row wise concatenate
y_update_green = [x1_green_not_embed; b_green];   % row wise concatenate
y_update_blue = [x1_blue_not_embed; b_blue];   % row wise concatenate
%%%%%%%%%%%%%% this above stream is transmitted %%%%%%%

%%%% reconstruction

%%%%%separate  real coefficients and measurements from y_update
x_real_red = y_update_red(1:k1,:);       % k1 is size of ordr_not_embed
x_real_green = y_update_green(1:k1,:);       % k1 is size of ordr_not_embed
x_real_blue = y_update_blue(1:k1,:);       % k1 is size of ordr_not_embed

%%%%%%%% perform OMP%%%%%%%
%%% let sparsity is K or set residual
%%%K=n/2;       for OMP
%%%%%%% let K as residual
K=1e-2;     %for OMP
%%%%%%%%%%% solve by l1 min minization 

%Running the recovery Algorithm
% tic        % clock start time
% 
% toc         % elapsed time
options.tol = 1e-3;  % tolerance
options.nbr_max_atoms = m;  %%options.nbr_max_atoms = 200;
%options.nbr_max_atoms = m/2;  %%options.nbr_max_atoms = k;
    tic
    options.use_slow_code = 0;
%%%%%%%%%%%%% for RED %%%%%%%%%%%%%%
for i=1:(row*col)/(blk*blk)
    y_temp_red=b_red(:,i);
    %Calculating Initial guess%    
    x0_red=A2_normalize'*y_temp_red;
    x_temp_red=l1eq_pd(x0_red,A2_normalize,[],y_temp_red,1e-5);% function in the file l1eq_pd.m containing in the same folder
   %x_temp=perform_omp(A2_normalize,y_temp,options);
   % [x_temp]= OMP (A2_normalize,y_temp,K);
    x_update_red(:,i)=x_temp_red;
end
%%%%%%%%%%%%% for green %%%%%%%%%%%%%%
for i=1:(row*col)/(blk*blk)
    y_temp_green=b_green(:,i);
    %Calculating Initial guess%    
    x0_green=A2_normalize'*y_temp_green;
    x_temp_green=l1eq_pd(x0_green,A2_normalize,[],y_temp_green,1e-5);% function in the file l1eq_pd.m containing in the same folder
   %x_temp=perform_omp(A2_normalize,y_temp,options);
   % [x_temp]= OMP (A2_normalize,y_temp,K);
    x_update_green(:,i)=x_temp_green;
end
%%%%%%%%%%%%% for RED %%%%%%%%%%%%%%
for i=1:(row*col)/(blk*blk)
    y_temp_blue=b_blue(:,i);
    %Calculating Initial guess%    
    x0_blue=A2_normalize'*y_temp_blue;
    x_temp_blue=l1eq_pd(x0_blue,A2_normalize,[],y_temp_blue,1e-5);% function in the file l1eq_pd.m containing in the same folder
   %x_temp=perform_omp(A2_normalize,y_temp,options);
   % [x_temp]= OMP (A2_normalize,y_temp,K);
    x_update_blue(:,i)=x_temp_blue;
end
x_recovered_red = x_update_red;     % size k2
x_recovered_green = x_update_green;     % size k2
x_recovered_blue = x_update_blue;     % size k2


%%% combined x_real and x_update according to order
x_combined_red = zeros(blk*blk,(row*col)/(blk*blk));
x_combined_red(order_can_embed,:) = x_recovered_red(1:n,:);  % n is size of recovered signal/origina signal in which we performed compressed sensong
x_combined_red(order_not_embed,:) = x_real_red(1:k1,:);    % not ebbedded signal

x_combined_green = zeros(blk*blk,(row*col)/(blk*blk));
x_combined_green(order_can_embed,:) = x_recovered_green(1:n,:);  % n is size of recovered signal/origina signal in which we performed compressed sensong
x_combined_green(order_not_embed,:) = x_real_green(1:k1,:);    % not ebbedded signal

x_combined_blue = zeros(blk*blk,(row*col)/(blk*blk));
x_combined_blue(order_can_embed,:) = x_recovered_blue(1:n,:);  % n is size of recovered signal/origina signal in which we performed compressed sensong
x_combined_blue(order_not_embed,:) = x_real_blue(1:k1,:);    % not ebbedded signal

%%%%%%%%%%%%%%%%%Image generation
x2_red=col2im(x_combined_red,[blk blk],[row col],'distinct');
x_reconstruct_red=uint8(blkproc(x2_red,[blk blk],fun2));
x2_green=col2im(x_combined_green,[blk blk],[row col],'distinct');
x_reconstruct_green=uint8(blkproc(x2_green,[blk blk],fun2));
x2_blue=col2im(x_combined_blue,[blk blk],[row col],'distinct');
x_reconstruct_blue=uint8(blkproc(x2_blue,[blk blk],fun2));
x_recovered(:,:,1)=x_reconstruct_red;
x_recovered(:,:,2)=x_reconstruct_green;
x_recovered(:,:,3)=x_reconstruct_blue;
% save fn_proposed x_reconstruct;
 PSNR = psnr(x,x_recovered,255);
disp(abs(PSNR))

figure,imshow(x_recovered);
imwrite(x_recovered,'x_recovered_lena_color_u=14_q=22.jpeg');
% figure,imhist(x);
% figure,imhist(x_reconstruct);
% 
% %%%%%%%%%%%%%% MSE %%%%%%%%%%%%%%%%%%%
Mean_Square_Error = MSE(x,x_recovered);
disp('Mean_Square_Error is')
disp(abs(Mean_Square_Error))
% 
% %%%%%%%%%%%%%%%%%%%%%% maximum dfference %%%%%%%%%%
% %max_diff =  max(max(x-x_recovered));
% 
% %%%%%%% bit error rate
% [number,ratio] = biterr(x,x_recovered);
% 
% 
% %%%%%%%%%%%% findind normalized corelation %%%%%%%%%%%%%
x_d_red=im2double(x(:,:,1));
x_d_green=im2double(x(:,:,2));
x_d_blue=im2double(x(:,:,3));
x_recovered_d_red=im2double(x_recovered(:,:,1));
x_recovered_d_green=im2double(x_recovered(:,:,2));
x_recovered_d_blue=im2double(x_recovered(:,:,3));
l1_red=0;
l1_green=0;
l1_blue=0;
l2_red=0;
l2_green=0;
l2_blue=0;
for i=1:512
for j=1:512
    l1_red=l1_red+x_d_red(i,j)*x_recovered_d_red(i,j);
    l2_red=l2_red+x_d_red(i,j)*x_d_red(i,j);
    l1_green=l1_green+x_d_green(i,j)*x_recovered_d_green(i,j);
    l2_green=l2_green+x_d_green(i,j)*x_d_green(i,j);
    l1_blue=l1_blue+x_d_blue(i,j)*x_recovered_d_blue(i,j);
    l2_blue=l2_blue+x_d_blue(i,j)*x_d_blue(i,j);
end
end
nc_red=l1_red/l2_red;
nc_green=l1_green/l2_green;
nc_blue=l1_blue/l2_blue;
fprintf('The Normalized corelation of red is %0.4f.\n',nc_red);
fprintf('The Normalized corelation of red is %0.4f.\n',nc_green);
fprintf('The Normalized corelation of red is %0.4f.\n',nc_blue);
fprintf('The average Normalized corelation is %0.4f.\n',(nc_red+nc_green+nc_blue)/3);
% 
% %%%%%%%%%%% SSIM matching %%%%%%%%%%%%%%%%%%%
 img1=x;
 img2=x_recovered;
% [mssim, ssim_map] = ssim_index(img1, img2);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
[ssimval, ssimmap] = ssim(img1, img2);      %% for color image %% ssim.m  also matlab have ssim function
fprintf('The SSIM value is %0.4f.\n',ssimval);
figure, imshow(ssimmap,[]);
%imshow(max(0, ssim_map).^4)  %Shows the SSIM index map
title(sprintf('ssim Index Map - Mean ssim Value is %0.4f',ssimval));
% 
 Entropy_cover=entropy(x);
 Entropy_stego=entropy(x_recovered);
disp('Entropy of cover image is')
disp(abs(Entropy_cover))
disp('Entropy of stego image is')
disp(abs(Entropy_stego))
