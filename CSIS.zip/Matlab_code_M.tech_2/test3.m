
clc;
clear;
close all;
clear all
clc;

x=imread('boat.bmp');
figure,imshow(x),title('Original Image');

blk=8; % image is decomposed using 8x8 blocks

[row col]=size(x);
%order=[1 9 2 3 10 17 25 18 11 4 5 12 19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];

order=[33 41 49 57 26 34 42 50 19 27 35 43 12 20 28 36 5 13 21 29 6 14 22 7 15 8];

fun1=@dct2;
fun2=@idct2;
J = blkproc(x,[blk blk],fun1);
x1=im2col(J,[blk blk],'distinct');
x1=x1'; 

% modified quantization table

q=[16 11 10 16 1 1 1 1; 12 12 14 1 1 1 1 55; 14 13 1 1 1 1 69 56; 14 1 1 1 1 87 80 62;
    1 1 1 1 68 109 103 77; 1 1 1 64 81 104 113 92; 1 1 78 87 103 121 120 101; 1 92 95 98 112 100 103 99];

q1= im2col(q,[8 8],'distinct');
q1=q1';

% quantization

a=zeros((row*row)/(blk*blk),blk*blk);   % a has dimention 4096x64 for 512x512 image block size 8x8
for i=1:(row*col)/(blk*blk)
    for j=1:blk*blk
        a(i,j)=(x1(i,j)/q1(1,j));
        a=int8(a);
    end
end
save fn a;

count=0;
for i=1:(row*col)/(blk*blk)
    for j=1:26
        if a(i,order(1,j))== -1 || a(i,j)== 0 || a(i,j)==1
            continue;
        else
           count=count+1; 
        end
    end
end

%----------------------Message Generation--------------

d=rand(1,count*2);
dd=find(d>.5);                                  % run command whos str1 ..problem is size of str1 is very large
str1=zeros(1,count*2);
str1(dd)=1;

 
% c=input('enter the message ','s');
% d=uint8(c);
% str=dec2bin(d,7);
% [r1 c1]=size(str);
% str1=im2col(str',[c1 r1],'distinct');
% str1=str1';

aa=a;
k=1;
for i=1:(row*col)/(blk*blk)
    for j=1:26                                        
        if aa(i,order(1,j))==-1 || aa(i,order(1,j))== 0 || aa(i,order(1,j))==1
            continue;
        else
        if mod(aa(i,order(1,j)),2)==0
            if mod(aa(i,order(1,j)),4)==0
                if (k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==0
                    aa(i,order(1,j))=aa(i,order(1,j))+1;
                    k=k+2;   
                elseif((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==1)
                     aa(i,order(1,j))=aa(i,order(1,j))-1;
                    k=k+2;
                elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==0)
                     aa(i,order(1,j))=aa(i,order(1,j));
                    k=k+2;
                elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==1)
                     aa(i,order(1,j))=aa(i,order(1,j))+2;
                    k=k+2;
                end     
            else
                if((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==0)
                     aa(i,order(1,j))=aa(i,order(1,j))-1;
                    k=k+2;
                elseif((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==1)
                     aa(i,order(1,j))=aa(i,order(1,j))+1;
                    k=k+2;
                elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==0)
                     aa(i,order(1,j))=aa(i,order(1,j))+2;
                    k=k+2;
                elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==1)
                     aa(i,order(1,j))=aa(i,order(1,j));
                    k=k+2;
                end  
            end
        else
%             aa(i,order(1,j))=aa(i,order(1,j))-1;
            if mod(aa(i,order(1,j))-1,2)==0
                if mod(aa(i,order(1,j))-1,4)==0
                    if((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==0)
                     aa(i,order(1,j))=aa(i,order(1,j));
                    k=k+2;   
                    elseif((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==1)
                     aa(i,order(1,j))=aa(i,order(1,j))+2;
                    k=k+2;
                    elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==0)
                     aa(i,order(1,j))=aa(i,order(1,j))-1;
                    k=k+2;
                    elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==1)
                    aa(i,order(1,j))=aa(i,order(1,j))+1;
                    k=k+2;
                    end     
                else
                     if((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==0)
                     aa(i,order(1,j))=aa(i,order(1,j))+2;
                    k=k+2;
                    elseif((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==1)
                     aa(i,order(1,j))=aa(i,order(1,j));
                    k=k+2;
                     elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==0)
                     aa(i,order(1,j))=aa(i,order(1,j))+1;
                    k=k+2;
                    elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==1)
                     aa(i,order(1,j))=aa(i,order(1,j))-1;
                    k=k+2;
                    end  
                end          
                
            end
        end
        end
    end
end

save fn2 aa;
       %dequantization...........
            b=double(aa);
            % q1=int8(q1);         % q1 is double data type and b is int data type so d_a is double data type
           d_a =zeros((row*row)/(blk*blk),blk*blk);   % a has dimention 4096x64 for 512x512 image block size 8x8
for i=1:(row*col)/(blk*blk)
    for j=1:blk*blk
        d_a(i,j)=(b(i,j)*q1(1,j));         % creating problem
%         d_a=int8(d_a);              % size is 4096 by 64
       
    end
end
%              dd_a=typecast(d_a(:),'uint8');    % conversion from int8 to uint8 it convert column wise now dd_a is 4096*64 by 1
%             qqq=zeros(blk*blk,(row*row)/(blk*blk));     % initialize qqq 4096 by 64
%             for ii=1:blk*blk
%                   for jj=1:row*col
%             qqq(ii,jj)=dd_a((ii-1)*row*col+jj,1);         % qqq is 64 by 4096
%                   end
%              end
%            qqq=qqq';                                    % qqq is 4096 by dd64 now it is same as d_a
%              
%              dd_a=typecast(d_a(:),'double');    % conversion from int8 to double it convert column wise now dd_a is 4096*64 by 1
%             dd_a2=dd_a';                        % size is 1 by 4096*64
%             dd_a3=reshape(dd_a2,[(row*col)/(blk*blk) blk*blk]);   % dd_a size is 4096 by 64 same as 'aa'

             
             x2=col2im(d_a',[blk blk],[row col],'distinct');
            DCTcompressed=uint8(blkproc(x2,[blk blk],fun2));
            save fn3 DCTcompressed;
psnr(x,DCTcompressed,255);
figure,imshow(DCTcompressed);
%imwrite(DCTcompressed,'jpegcompressed.jpeg');
figure,imhist(x);
figure,imhist(DCTcompressed);
