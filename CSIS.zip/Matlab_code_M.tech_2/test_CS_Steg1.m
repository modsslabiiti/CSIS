%%%%%% image compressed sensing using random measurement matrix

clc;
clear;
close all;
clear all
clc;
path(path, 'D:\IIT INDORE\phd data\compressed sensing\matlab code\CoSaMP_OMP');
x=imread('lena.bmp');
figure,imshow(x),title('Original Image');

blk=8; % image is decomposed using 8x8 blocks

[row col]=size(x);
%order=[1 9 2 3 10 17 25 18 11 4 5 12 19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];

%order=[33 41 49 57 26 34 42 50 19 27 35 43 12 20 28 36 5 13 21 29 6 14 22 7 15 8];

fun1=@dct2;
fun2=@idct2;
% block wise sparsification 
J = blkproc(x,[blk blk],fun1);
x1=im2col(J,[blk blk],'distinct');  % taking blk x blk matrix as column.....
% x1=x1'; 
n=blk*blk;
m=n/4; 
A=randn(m,n);
A_normalize=normc(A);
       
%%%% fiinding measurements y=A*x
for i=1:(row*col)/(blk*blk)
    y(:,i)=A_normalize*x1(:,i);
end

%%%%%%%% perform OMP%%%%%%%
%%% let sparsity is K 
K=n/4;
for i=1:(row*col)/(blk*blk)
    y_temp=y(:,i)';
    [x_temp]= OMP (K,y_temp,A_normalize);
    x_update(:,i)=x_temp';
end
%%%%%%%%%%%%%%%%%Image generation
x2=col2im(x_update,[blk blk],[row col],'distinct');
            x_reconstrcut=uint8(blkproc(x2,[blk blk],fun2));
            save fn3 x_reconstrcut;
psnr(x,x_reconstrcut,255);
figure,imshow(x_reconstrcut);
imwrite(x_reconstrcut,'x_reconstrcut_lena.jpeg');
figure,imhist(x);
figure,imhist(x_reconstrcut);
