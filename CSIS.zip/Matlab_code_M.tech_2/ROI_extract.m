%--------------------------------------------------------------------------
                      %%% charge et lecture de l'image %%%
%--------------------------------------------------------------------------                
[filename, pathname] = uigetfile('lena.bmp', 'C:\Users\RohitA\Downloads\ROI_extract');% only image Bitmap
if isequal(filename, 0) || isequal(pathname, 0)   
    disp('Image input canceled.');  
   X = [];    map = []; 
else
    [X,MAP]=imread(fullfile(pathname, filename));%Lecture d'image.
end;
lsz=length(size(X));
if lsz==3
X=rgb2gray(X);
end
%---------------------------------------------------------------------------------------------------
 %%%Region of interest extraction ( Extraction d'une r�gion d'int�ret � main libre )by free hand %%%
%---------------------------------------------------------------------------------------------------
im0=X;
X=double(X);
h_im = imshow(im0),title('Choose ROI from the figure');
%helpdlg('Choose ROI from the figure','Point Selection');
h = imfreehand;
position = wait(h);
e = impoly(gca,position);
BW = createMask(e,h_im);
ROI=X.*BW;
figure,imshow(ROI,[]);
im_DIF=X-ROI;
X=X-ROI;
figure,imshow(im_DIF,[]);
ROI=uint8(ROI);im_DIF=uint8(im_DIF);
imwrite(ROI,'Region of interest.bmp','bmp');
imwrite(im_DIF,'Image difference.bmp','bmp');