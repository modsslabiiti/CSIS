clear all;
clc;
close all;

load fn_proposed;     % write command 'save fn_proposed x_reconstrcut ' 'x_reconstrcut' is from test_CS_steg7_7.m
c2=zeros(256,1);
for i=0:255
    c2(i+1)=i;
end
h1=hist(x_reconstruct(:),c2);
X=zeros(128,1);         % frequency of pixel 2k
Y=zeros(128,1);         % frequency of pixel 2k+1
 for i=1:128
X(i)=h1(1,2*i-1);
Y(i)=h1(1,2*i);
 end
Z=zeros(128,1);         % expected frequency pixel 2k of gray scale image
for i=1:128
Z(i)=(X(i)+Y(i))/2;
end
Xn=0;
for i=1:128
    if Z(i)==0
        continue;
    else
        Xn=Xn+((Y(i)-Z(i))*(Y(i)-Z(i))/Z(i));
    end
end
diff=zeros(128,1);         % difference of even and odd pixel value frequency
 for i=1:128
diff(i)=abs(X(i)-Y(i));
%diff(i)=abs(Z(i)-Y(i));
 end
 figure,plot(1:128,diff);
 
 %%%% Probability of embedding.........see chi-square attack
 
 fun = @(u) exp(-u/2).*power(u,62.5);
 
 q = integral(fun,0,Xn);
 q1=q/(power(2,63.5));        % 255/2 = 127... (127-1/2) = 63
 q2=q1/gamma(63.5);           
 q3=(1-q2);       % probability of embedding
 q4=q3*100;         % probability of embedding in percentage