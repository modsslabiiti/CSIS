%%% measurement matrix using maximum norm-2 subset of hamadard square
%%% matrix
s = sparse(20,1);
s(1,1)=10;s(2,1)=-5;s(5,1)=11;s(7,1)=14;s(11,1)=10;s(12,1)=10; % sparse vector
% let initinal measuremenet matrix A
n=20;
A = hadamard(n);
A_normalize=normc(A);

m=9;        
s2=A_normalize*s;     % full n measurements 
max_sum=0;
for c = 1:(n-m)
    sum=0;
    for r = c:(m+c-1)
        sum=sum+s2(r,1)*s2(r,1);
    end
    
    if (sum>max_sum)
        max_sum=sum;
        index=c;
    end
end
%A=rand(n);%A = randn(n);
%A = normrnd(0,1,[20 20]);
%A = hadamard(n);
%adaptive measurement mar=trix of size m x n
AA=A(index:index+m-1,:);      % size m x n (m<n)
AAA=normc(AA);              %normalize column of AA
s2_update=AAA*s;            % only m measurements 
norm_s=norm(s,2);
norm_s2=norm(s2,2);  % approximately same as norm_s
norm_s2_update=norm(s2_update,2);  % approximately same as norm_s