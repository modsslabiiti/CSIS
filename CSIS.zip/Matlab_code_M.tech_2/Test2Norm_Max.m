m = 20; n = 10; p = 4;
A = randn(m,n); b = randn(m,1);
C = randn(p,n); d = randn(p,1); e = rand;
a = randn(1,10);
a = a.*a;
c = ones(1,10);
k = 5;
cvx_begin
    variable x(n)
    minimize( a* x )
    subject to
        c * x == k
        %0 < x <1
        %0>= x >=1
       % x = 0 or 1
        norm( x, Inf ) <= e
cvx_end