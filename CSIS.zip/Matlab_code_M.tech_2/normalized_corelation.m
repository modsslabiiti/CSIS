function [nc]=normalized_corelation(x,x_reconstruct)
x_d=im2double(x);
x_reconstrcut_d=im2double(x_reconstruct);
for i=1:512
for j=1:512
l1=x_d(i,j)*x_reconstrcut_d(i,j);
l2=x_d(i,j)*x_d(i,j);
end
end
nc=l1/l2;