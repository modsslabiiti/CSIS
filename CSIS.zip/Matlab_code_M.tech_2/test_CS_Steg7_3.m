%%%%%% image compressed sensing using hadamard random measurement matrix
%%%%%% with selecting m according to coffecient of signal. solve by l1 minimization
%%here we are not taking taking measurements of full signal......skiping
%%some coefficients (12) if we do not normalize masurement matrix then
%%embedding capasity is more and 25 coefficients for measurements.
clc;
clear;
close all;
clear all
clc;
%ylim([0 500]);
%R_size.YLim = [0, 5000];
path(path, 'D:\IIT INDORE\phd data\matlab-toolboxes-master\toolbox_sparsity');
path(path, 'D:\IIT INDORE\phd data\compressed sensing\matlab code\CoSaMP_OMP');
path(path, 'D:\Document related to B.Tech and M.tech\Document related to M.Tech\Matlab_code_M.tech_2\Images result');
path(path, 'D:\Document related to B.Tech and M.tech\Document related to M.Tech\Matlab_code_M.tech_2\Images result\Test images');
cover = input('Enter cover image: ', 's');
x=imread(cover);
%x=imread('cameraman.tif');
figure,imshow(x),title('Original Image');

blk=8; % image is decomposed using 8x8 blocks

[row col]=size(x);
%order=[1 9 2 3 10 17 25 18 11 4 5 12 19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];
order_not_embed = [1 9 2 3 10 17 25 18 11 4 5 12]; % taking 12 coeffieints which as taken as these are
order_can_embed = [19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];
%order=[33 41 49 57 26 34 42 50 19 27 35 43 12 20 28 36 5 13 21 29 6 14 22 7 15 8];
k1=size(order_not_embed);
k1=k1(2);
k2=size(order_can_embed);
k2=k2(2);
fun1=@dct2;
fun2=@idct2;
% block wise sparsification 
J = blkproc(x,[blk blk],fun1);
x1=im2col(J,[blk blk],'distinct');  % taking blk x blk matrix as column.....
x1_not_embed = x1(order_not_embed,:);
x1_can_embed = x1(order_can_embed,:);
% x1=x1'; 
%n=blk*blk;
% n=blk*blk - size(order_not_embed);      % or n is size of x1_can_embed
% n=n(2);
% %m=n/4;      % numner of measurements
n=k2;
%A = hadamard(n);    % for hadamard n must be an integer and n, n/12 or n/20 must be a power of 2.
A = hadamard(blk*blk);
%A=rand(blk*blk);
p = randperm(blk*blk,n);
A = A(:,p);
%A_normalize=normc(A);

% index for measurement matrix
%{
for i=1:blk/2           %for m=n/4
    for j=1:blk/2
        index(j+(i-1)*blk/2)=j+(i-1)*blk;
    end
end
%}
% measurement matrix index it is coefficceints index which are part of zizzag scan order of x1_can_embed
index=[1 2 3 4 5 6 7 8 9 10 12 13 14 15 18 19 20 21 25 26 27 28 33 34 35]; % from x1_can_embed (taking 25)
%index=[1 2 3 4 5 6 7 8 9 10 12 13 14 15 18 19 20 21 25 26 27 28 33 34 35 41 42 57]; % from x1_can_embed (taking 28)
%index=[1 2 3 4 5 6 7 8 9 10 12 13 14 15 18 19 20 21 25 26 27 28 33 34 35 41 42 57 50 43]; % from x1_can_embed (taking 30)
%index=[1 2 3 4 5 6 7 8 9 10 12 13 14 15 18 19 20 21 25 26 27 28 33 34 35 41 42 57 50 43 36 29 22 24 31]; % from x1_can_embed (taking 35)

m=size(index);
m=m(2);
%%%%% updating measurement matrix
A2=A(index,:);      % size m x n (m<n)
A2_normalize=normc(A2);
A2_normalize=A2;

%%%% fiinding measurements y=A*x
for i=1:(row*col)/(blk*blk)
    y1(:,i)=A2_normalize*x1_can_embed(:,i);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% embedding 
%%%%%%% quantize y to int8 y=y/20; then y2=int8(y)
y2=int8(y1);
y2=y2';
 %%%%%%%%%%%%%%%% count message capacity
 count=0;
for i=1:(row*col)/(blk*blk)
    for j=1:m      % number of measurements
        if y2(i,j)== -1 || y2(i,j)== 0 || y2(i,j)==1
            continue;
        else
           count=count+1; 
        end
    end
end

%----------------------Message Generation--------------

d=rand(1,count*2);
dd=find(d>.5);                                  % run command whos str1 ..problem is size of str1 is very large
str1=zeros(1,count*2);
str1(dd)=1;
 
% c=input('enter the message ','s');
% d=uint8(c);
% str=dec2bin(d,7);
% [r1 c1]=size(str);
% str1=im2col(str',[c1 r1],'distinct');
% str1=str1';

%order_can_embed = [11 4 5 12 19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];

% embedding order....we can embed in random order or in sequential order or
% in zizzag scan order (it is position of order_can_embed in
% x1_can_embed)...not required becoz we have only m measurements in which
% we are embedding
%order_embed = [6 1 2 7 12 18 25 33 26 19 13 8 3 4 9 14 20 27 34 41 49 42 35 28 21 15 1 5];
order_embed = randperm(m);      % took random embedding index
aa=y2;
k=1;
for i=1:(row*col)/(blk*blk)
    for j=1:m                                        
        if aa(i,order_embed(1,j))==-1 || aa(i,order_embed(1,j))== 0 || aa(i,order_embed(1,j))==1
            continue;
        else
        if mod(aa(i,order_embed(1,j)),2)==0
            if mod(aa(i,order_embed(1,j)),4)==0
                if (k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==0
                    aa(i,order_embed(1,j))=aa(i,order_embed(1,j))+1;
                    k=k+2;   
                elseif((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==1)
                     aa(i,order_embed(1,j))=aa(i,order_embed(1,j))-1;
                    k=k+2;
                elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==0)
                     aa(i,order_embed(1,j))=aa(i,order_embed(1,j));
                    k=k+2;
                elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==1)
                     aa(i,order_embed(1,j))=aa(i,order_embed(1,j))+2;
                    k=k+2;
                end     
            else
                if((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==0)
                    if (aa(i,order_embed(1,j))~=2)
                        aa(i,order_embed(1,j))=aa(i,order_embed(1,j))-1;
                    else
                        aa(i,order_embed(1,j))=aa(i,order_embed(1,j))+3;
                    end
                    k=k+2;
                elseif((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==1)
                     if (aa(i,order_embed(1,j))~=-2)
                        aa(i,order_embed(1,j))=aa(i,order_embed(1,j))+1;
                    else
                        aa(i,order_embed(1,j))=aa(i,order_embed(1,j))-3;
                    end
                    k=k+2;
                elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==0)
                     if (aa(i,order_embed(1,j))~=-2)
                        aa(i,order_embed(1,j))=aa(i,order_embed(1,j))+2;
                    else
                        aa(i,order_embed(1,j))=aa(i,order_embed(1,j))-2;
                    end
                    k=k+2;
                elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==1)
                     aa(i,order_embed(1,j))=aa(i,order_embed(1,j));
                    k=k+2;
                end  
            end
        else
%             %if mod(aa(i,order_embed(1,j))-1,2)==0
                if mod(aa(i,order_embed(1,j))-1,4)==0
                    if((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==0)
                     aa(i,order_embed(1,j))=aa(i,order_embed(1,j));
                    k=k+2;   
                    elseif((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==1)
                     aa(i,order_embed(1,j))=aa(i,order_embed(1,j))-2;
                    k=k+2;
                    elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==0)
                     aa(i,order_embed(1,j))=aa(i,order_embed(1,j))-1;
                    k=k+2;
                    elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==1)
                    aa(i,order_embed(1,j))=aa(i,order_embed(1,j))+1;
                    k=k+2;
                    end     
                else
                     if((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==0)
                     aa(i,order_embed(1,j))=aa(i,order_embed(1,j))+2;
                    k=k+2;
                    elseif((k+1)<(count*2)&&str1(1,k)==0&&str1(1,k+1)==1)
                     aa(i,order_embed(1,j))=aa(i,order_embed(1,j));
                    k=k+2;
                     elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==0)
                     aa(i,order_embed(1,j))=aa(i,order_embed(1,j))+1;
                    k=k+2;
                    elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==1)
                     aa(i,order_embed(1,j))=aa(i,order_embed(1,j))-1;
                    k=k+2;
                    end  
                end          
                
            %end
        end
        end
    end
end
save fn2 aa;

%%%%%%%%%%%%%%%%%%%%%%% Message recovery (extraction) check %%%%%%%%%%%%%%%%%%%%
str1_recover=zeros(1,count*2);
k2=1;
for i=1:(row*col)/(blk*blk)
    for j=1:m                                        
        if aa(i,order_embed(1,j))==-1 || aa(i,order_embed(1,j))== 0 || aa(i,order_embed(1,j))==1
            continue;
        else
            if mod(aa(i,order_embed(1,j)),2)==0
              if mod(aa(i,order_embed(1,j)),4)==0
                  str1_recover(1,k2)=1;
                  str1_recover(1,k2+1)=0;
                  k2=k2+2;
              else
                  str1_recover(1,k2)=1;
                  str1_recover(1,k2+1)=1;
                  k2=k2+2;
              end
            else
                %if mod(aa(i,order_embed(1,j))-1,2)==0
                 if mod(aa(i,order_embed(1,j))-1,4)==0
                    str1_recover(1,k2)=0;
                    str1_recover(1,k2+1)=0;
                    k2=k2+2;
                 else
                    str1_recover(1,k2)=0;
                    str1_recover(1,k2+1)=1;
                    k2=k2+2;
                 end
                %end
            end           
        end
    end
end
Error_message=str1(1,:)-str1_recover(1,:);
save Error_CS_steg7_7 Error_message;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

b=double(aa);           % b is measurements with message embedded 4096xm
b=b';                   % mx4096

%%%% combined measurement i.e. concatination of 'x1_not_embed' and 'b'
y_update = zeros(m+k1, (row*col)/(blk*blk)); % k1 is size of order_not_embed
%y_update(order_not_embed,:)=x1(order_not_embed,:);
y_update = [x1_not_embed; b];   % row wise concatenate
%%%%%%%%%%%%%% this above stream is transmitted %%%%%%%

%%%% reconstruction

%%%%%separate  real coefficients and measurements from y_update
x_real = y_update(1:k1,:);       % 8 is size of ordr_not_embed

%%%%%%%% perform OMP%%%%%%%
%%% let sparsity is K or set residual
%%%K=n/2;       for OMP
%%%%%%% let K as residual
K=1e-2;     %for OMP
%%%%%%%%%%% solve by l1 min minization 

%Running the recovery Algorithm
% tic        % clock start time
% 
% toc         % elapsed time
options.tol = 1e-3;  % tolerance
options.nbr_max_atoms = m;  %%options.nbr_max_atoms = 200;
%options.nbr_max_atoms = m/2;  %%options.nbr_max_atoms = k;
    tic
    options.use_slow_code = 0;

for i=1:(row*col)/(blk*blk)
    y_temp=b(:,i);
    %Calculating Initial guess%    
    x0=A2_normalize'*y_temp;
     lambda = 0.001*norm(A2_normalize'*y_temp,'inf');
 % x_temp = lasso(A2_normalize,y_temp,'Lambda',lambda);%toolbox 
  x_temp = lasso_my(A2_normalize,y_temp,lambda,1,1.5);
    %x_temp=l1eq_pd(x0,A2_normalize,[],y_temp,1e-5);% function in the file l1eq_pd.m containing in the same folder
   %x_temp=perform_omp(A2_normalize,y_temp,options);
   % [x_temp]= OMP (A2_normalize,y_temp,K);
    x_update(:,i)=x_temp;
end
x_recovered = x_update;     % size k2

%%% combined x_real and x_update according to order
x_combined = zeros(blk*blk,(row*col)/(blk*blk));
x_combined(order_can_embed,:) = x_recovered(1:n,:);  % n is size of recovered signal/origina signal in which we performed compressed sensong
x_combined(order_not_embed,:) = x_real(1:k1,:);    % not ebbedded signal

%%%%%%%%%%%%%%%%%Image generation
x2=col2im(x_combined,[blk blk],[row col],'distinct');
x_reconstruct=uint8(blkproc(x2,[blk blk],fun2));
save fn3 x_reconstruct;
PSNR = psnr(x,x_reconstruct,255);
disp('PSNR of message image to extracted image is')
disp(abs(PSNR))

figure,imshow(x_reconstruct);
imwrite(x_reconstruct,'x_reconstrcut_peppers_u=12_q=28.jpeg');
figure,imhist(x);
figure,imhist(x_reconstruct);

%%%%%%%%%%%%%% MSE %%%%%%%%%%%%%%%%%%%
Mean_Square_Error = MSE(x,x_reconstruct);
disp('Mean_Square_Error is')
disp(abs(Mean_Square_Error))

%%%%%%%%%%%%%%%%%%%%%% maximum dfference %%%%%%%%%%
%max_diff =  max(max(x-x_reconstruct));

%%%%%%% bit error rate
[number,ratio] = biterr(x,x_reconstruct);

%%%%%%%%%%%% findind normalized corelation %%%%%%%%%%%%%
%nc=normalized_corelation(x,x_reconstruct);
%function [nc]=normalized_corelation(x,x_reconstruct)
x_d=im2double(x);
x_reconstruct_d=im2double(x_reconstruct);
l1=0;
l2=0;
for i=1:512
for j=1:512
l1=l1+x_d(i,j)*x_reconstruct_d(i,j);
l2=l2+x_d(i,j)*x_d(i,j);
end
end
nc=l1/l2;

%%%%%%%%%%% SSIM matching %%%%%%%%%%%%%%%%%%%
img1=x;
img2=x_reconstruct;
[mssim, ssim_map] = ssim_index(img1, img2);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
%[mssim, ssim_map] = ssim(img1, img2);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
%imshow(max(0, ssim_map).^4)  %Shows the SSIM index map

Entropy_cover=entropy(x);
Entropy_stego=entropy(x_reconstruct);
disp('Entropy of cover image is')
disp(abs(Entropy_cover))
disp('Entropy of stego image is')
disp(abs(Entropy_stego))