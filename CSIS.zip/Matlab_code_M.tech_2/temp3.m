% hadamard sensing matrix,,,,,it is just a example
I=imread('lena.bmp');
I1=double(I);
[m, n]=size(I);
H=hadamard(n);
m1=randperm(n,m/2);
H1=H(m1,:);
for i=1:n
    I2(:,i)=H1*I1(:,i);
end

for i=1:n
    I2_temp=I2(:,i);
    x0=H1'*I2_temp;
I1_recons_temp=l1eq_pd(x0,H1,[],I2_temp,1e-5);
I1_recons(:,i)=I1_recons_temp;
end
Err=I1-I1_recons; 