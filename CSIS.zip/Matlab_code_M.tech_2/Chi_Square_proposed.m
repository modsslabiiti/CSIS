clear all;
clc;
close all;

load fn1;               % write command 'save fn1 x' 'x is the cover image from test_CS_Steg7_7.m file
load fn3;               % write command 'save fn3 x_reconstruct 
c1=zeros(256,1);
c2=zeros(256,1);
for i=0:255
    c1(i+1)=i;
    c2(i+1)=i;
end
h1=hist(x_reconstrcut(:),c1);
h2=hist(x(:),c2);
X1=zeros(128,1);         % frequency of pixel 2k
Y1=zeros(128,1);         % frequency of pixel 2k+1

X2=zeros(128,1);         % frequency of pixel 2k
Y2=zeros(128,1);         % frequency of pixel 2k+1

 for i=1:128
X1(i)=h1(1,2*i-1);
Y1(i)=h1(1,2*i);
X2(i)=h2(1,2*i-1);
Y2(i)=h2(1,2*i);
 end
Z1=zeros(128,1);         % expected frequency pixel 2k of gray scale image
Z2=zeros(128,1);         % expected frequency pixel 2k of gray scale image
for i=1:128
Z1(i)=(X1(i)+Y1(i))/2;
Z2(i)=(X2(i)+Y2(i))/2;
end
Xn1=0;
Xn2=0;
for i=1:128
    if Z1(i)==0
        continue;
    else
        Xn1=Xn1+((X1(i)-Z1(i))*(X1(i)-Z1(i))/Z1(i));
    end
end
for i=1:128
    if Z2(i)==0
        continue;
    else
        Xn2=Xn2+((X2(i)-Z2(i))*(X2(i)-Z2(i))/Z2(i));
    end
end
diff1=zeros(128,1);         % difference of even and odd pixel value frequency
diff2=zeros(128,1);         % difference of even and odd pixel value frequency
 for i=1:128
diff1(i)=abs(X1(i)-Y1(i));
diff2(i)=abs(X2(i)-Y2(i));
 end
 figure,plot(1:128,diff1);
 figure,plot(1:128,diff2);