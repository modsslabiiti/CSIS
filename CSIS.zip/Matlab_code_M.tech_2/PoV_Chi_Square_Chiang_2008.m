clear all;
clc;
close all;

load fn_chiang_2008;   % write command 'save fn_chiang_2008 DCTcompressed' 'DCTcompressed is from chiang_2008_jpeg.m
c2=zeros(256,1);
for i=0:255
    c2(i+1)=i;
end
h1=hist(DCTcompressed(:),c2);
X=zeros(128,1);         % frequency of pixel 2k
Y=zeros(128,1);         % frequency of pixel 2k+1
 for i=1:128
X(i)=h1(1,2*i-1);
Y(i)=h1(1,2*i);
 end
Z=zeros(128,1);         % expected frequency pixel 2k of gray scale image
for i=1:128
Z(i)=(X(i)+Y(i))/2;
end
Xn=0;
for i=1:128
    if Z(i)==0
        continue;
    else
        Xn=Xn+((X(i)-Z(i))*(X(i)-Z(i))/Z(i));
    end
end
diff=zeros(128,1);         % difference of even and odd pixel value frequency
 for i=1:128
diff(i)=abs(X(i)-Y(i));
 end
 figure,plot(1:128,diff);