% from the paper of High-performance JPEG steganography using complementary
% embedding strategy
clc;
clear;
close all;
clear all
clc;

cover = input('Enter cover image: ', 's');
x=imread(cover);
%x=imread('lena.bmp');
figure,imshow(x),title('Original Image');

blk=8; % image is decomposed using 8x8 blocks

[row col]=size(x);
order=[1 9 2 3 10 17 25 18 11 4 5 12 19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];

% order=[33 41 49 57 26 34 42 50 19 27 35 43 12 20 28 36 5 13 21 29 6 14 22 7 15 8];

fun1=@dct2;
fun2=@idct2;
J = blkproc(x,[blk blk],fun1);
x1=im2col(J,[blk blk],'distinct');
x1=x1'; 

q=[16 11 10 16 24 40 51 61; 12 12 14 19 26 58 60 55; 14 13 16 24 40 57 69 56; 14 17 22 29 51 87 80 62;
    18 22 37 56 68 109 103 77; 24 35 55 64 81 104 113 92; 49 64 78 87 103 121 120 101; 72 92 95 98 112 100 103 99];

q1= im2col(q,[8 8],'distinct');
q1=q1';

% quantization

a=zeros((row*row)/(blk*blk),blk*blk);   % a has dimention 4096x64 for 512x512 image block size 8x8
for i=1:(row*col)/(blk*blk)
    for j=1:blk*blk
        a(i,j)=(x1(i,j)/q1(1,j));
        a=int8(a);
    end
end

count=0;
for i=1:(row*col)/(blk*blk)
    for j=1:64
        if a(i,order(1,j))== 0
            continue;
        else
           count=count+1; 
        end
    end
end

%----------------------Message Generation--------------

d=rand(1,count*2);
dd=find(d>.5);                                  % run command whos str1 ..problem is size of str1 is very large
str1=zeros(1,count*2);
str1(dd)=1;

aa=a;
k=1;
for i=1:(row*col)/(blk*blk)
    for j=1:64                                        
        if aa(i,order(1,j))== 0
            continue;
        else
        if (aa(i,order(1,j))>0&&mod(aa(i,order(1,j)),2)==1)
                if (k+1)<count&&str1(1,k)==0&&aa(i,order(1,j))==1
                    aa(i,order(1,j))=aa(i,order(1,j))-2;
                    k=k+1;   
                elseif((k+1)<count&&str1(1,k)==0&&aa(i,order(1,j))~=1)
                     aa(i,order(1,j))=aa(i,order(1,j))-1;
                    k=k+1;
                elseif ((k+1)<count&&str1(1,k)==1)
                     aa(i,order(1,j))=aa(i,order(1,j));
                    k=k+1;
                end
         elseif (aa(i,order(1,j))>0&&mod(aa(i,order(1,j)),2)==0)
                if (k+1)<count&&str1(1,k)==1
                    aa(i,order(1,j))=aa(i,order(1,j))-1;
                    k=k+1;   
                elseif((k+1)<count&&str1(1,k)==0)
                     aa(i,order(1,j))=aa(i,order(1,j));
                    k=k+1;
                end
          elseif (aa(i,order(1,j))<0&&mod(aa(i,order(1,j)),2)==1)
                if (k+1)<count&&str1(1,k)==1
                    aa(i,order(1,j))=aa(i,order(1,j))-1;
                    k=k+1;   
                elseif((k+1)<count&&str1(1,k)==0)
                     aa(i,order(1,j))=aa(i,order(1,j));
                    k=k+1;
                end
           elseif (aa(i,order(1,j))<0&&mod(aa(i,order(1,j)),2)==0)
                if (k+1)<count&&str1(1,k)==0
                    aa(i,order(1,j))=aa(i,order(1,j))-1;
                    k=k+1;   
                elseif((k+1)<count&&str1(1,k)==1)
                     aa(i,order(1,j))=aa(i,order(1,j));
                    k=k+1;
                end
        end
        end
    end
end

        
       %dequantization...........
            b=double(aa);
            % q1=int8(q1);         % q1 is double data type and b is int data type so d_a is double data type
           d_a =zeros((row*row)/(blk*blk),blk*blk);   % a has dimention 4096x64 for 512x512 image block size 8x8
for i=1:(row*col)/(blk*blk)
    for j=1:blk*blk
        d_a(i,j)=(b(i,j)*q1(1,j));         % creating problem
%         d_a=int8(d_a);              % size is 4096 by 64
       
    end
end
             
             x2=col2im(d_a',[blk blk],[row col],'distinct');
            DCTcompressed=uint8(blkproc(x2,[blk blk],fun2));
            save fn_chiang_2008 DCTcompressed;
psnr(x,DCTcompressed,255);
figure,imshow(DCTcompressed);
%imwrite(DCTcompressed,'jpegcompressed.jpeg');
figure,imhist(x);
figure,imhist(DCTcompressed);
