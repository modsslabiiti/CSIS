%%% DWT and SVD and image procssing 
filename='lena.bmp';
coverImage = imread(filename);
Mc=size(coverImage,1);
Nc=size(coverImage,2);

a=10;


watermark = imread('peppers.bmp');

watermark=im2bw(watermark,0.05);
Mn=size(watermark,1);
Nn=size(watermark,2);

[LL,LH,HL,HH] = dwt2(coverImage,'haar');
%[LL1,LH1,HL1,HH1] = dwt2(HH,'haar');

Ih=idwt2([],[],[],HH,'haar');

[Uh,Sh,Vh]=svd(Ih);
[Uw,Sw,Vw]=svd(double(watermark));

Shw=Sh+a*Sw;**%%%%%ERROR OCCURRING HERE%%%%%**
VhT=transpose(Vh);
Ihw=Uh*Shw*VhT;
[LL2,LH2,HL2,HH2]=dwt2(Ihw,'haar');
watermarked_image=idwt2(LL,LH,LH,HH,'haar');
figure;
imshow(watermarked_image,[]);
title('Watermarked Image');