% fast discreate walsh hadamard transform sparsification and compressed
% sensing using hadamard sensing matrix
path(path, 'D:\IIT INDORE\phd data\matlab-toolboxes-master\toolbox_sparsity');
path(path, 'D:\IIT INDORE\phd data\compressed sensing\matlab code\CoSaMP_OMP');
I=imread('lena.bmp');
I1=double(I);%%I1=im2double(I);
[n1,n2]=size(I);
for i=1:n2
    I1_sparse(:,i)=fwht(I1(:,i));
end

m=n1/8;     % number of measurements
h=hadamard(n1); %hadamard matirx
h1=h(1:m,:);    % choose fisrt n row becoz energy conserved in first m coefficients 
for i=1:n2
    I1_measurements(:,i)=h1*I1_sparse(:,i); % measurements coefficients
end

% Recovery
options.tol = 1e-3;  % tolerance
options.nbr_max_atoms = m;  %%options.nbr_max_atoms = 200;
%options.nbr_max_atoms = m/2;  %%options.nbr_max_atoms = k;
    tic
    options.use_slow_code = 0;
for i=1:n2
    %I1_measurements_temp=I1_measurements(:,i)';
    I1_measurements_temp=I1_measurements(:,i);
   % x0=h1'*I1_measurements_temp;
%I1_sparse_recons_temp=l1eq_pd(x0,h1,[],I1_measurements_temp,1e-5);
%I1_sparse_recons_temp=OMP(m,I1_measurements_temp,h1);
I1_sparse_recons_temp=perform_omp(h1,I1_measurements_temp,options);
I1_sparse_recons_temp=OMP(h1,I1_measurements_temp,1e-12);   %CoSaMP_MP folder
%I1_sparse_recons(:,i)=I1_sparse_recons_temp';
I1_sparse_recons(:,i)=I1_sparse_recons_temp;

end

    toc

for i=1:n2
   I1_recons(:,i)=ifwht(I1_sparse_recons(:,i));
end
Err1=I1-I1_recons; 
I_recons=uint8(I1_recons);%%%I_recons=im2uint8(I1_recons);
Err2=I-I_recons;
