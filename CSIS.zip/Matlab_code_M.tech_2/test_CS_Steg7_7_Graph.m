%%%%%%%%%%% BER Bar chart %%%%%%%

x = categorical({'Peppers', 'Boat', 'Goldhill', 'Zelda', 'Living room', 'Tank', 'Airplane', 'Camera man'});
x = reordercats(x,{'Peppers', 'Boat', 'Goldhill', 'Zelda', 'Living room', 'Tank', 'Airplane', 'Camera man'});
BER = [34.70 36.43 37.32 36.23 33.13 34.43 34.56 36.47];
plot(x,BER,'b--o');
bar(x, BER, 'BarWidth', 0.3);
%%%%%%%%%%%%%%%%%%%%%%%%%

Pr_add = [.44 .48 .54 .46 .57 .53 .55 .52];
Pr_sub = [.56 .52 .46 .54 .43 .47 .45 .48];
plot(x,Pr_add,'r--o',x,Pr_sub,'b--*');
legend({'Probability of addition','Probability of subtraction'},'Location','southwest');

%bar(x,BER,'b');
% scatter(x,BER,'r');
% Epsilon_Primal = [0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002 0.002];
% %figure;
% plot(x,BER,'b');
%  xlabel('Images')
%  ylabel(BER ('%'));
% %title('')
% legend({'Primal Residual','Epsilon Primal'},'Location','southwest')
