% A = [-2, -3, 4, -1, -2, 1, 5, -3]
% k = 5;
% n = size(A);
% function [B BIndex RestVector RestVectorindex]= maxk2(A, k)
% B = 0;
% Index = [1:size(A)];
% RestVectorindex = Index;
% RestVector = A;
% sumIndex = 1;
% for i=1:k
% 
%  max_so_far = realmin;
%  max_ending_here = 0; 
% 
% 	for i = 1:n 
%         for j=
%     end
%     
% 		max_ending_here = max_ending_here + sqrt(a[i]; 
%         	if (max_so_far < max_ending_here) 
% 			max_so_far = max_ending_here; 
% 
%             if (max_ending_here < 0) 
% 			max_ending_here = 0;
%             end
%             end
%     end
%     

