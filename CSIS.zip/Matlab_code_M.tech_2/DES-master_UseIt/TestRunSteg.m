%%%%%%%%%
clc, clear all
key = round(rand(1,64));

load str1.mat % save('str1.mat','str1') in test_CS_Steg7_6.m
plain = str1;      
length = size(str1, 2);
rem_64 = rem(length, 64);
cipher = [];
for i=1:64:length - rem_64
    temp = plain(i:i+63);
    cipher_temp = enkripsi_des(temp, key);
    cipher = [cipher cipher_temp];
end
cipher = [cipher plain(i+64:length)];
save('cipher.mat', 'cipher'); % this is embedded using our steg

load str1_recover % save('str1_recover.mat','str1_recover') in test_CS_Steg7_6.m
cipher_recover = str1_recover; % here, str1_recover is the dummy data
%cipher_recover = cipher;
plain_de = [];
for i=1:64:length - rem_64
    temp2 = cipher_recover(i:i+63);
    plain_de_temp = dekripsi_des(temp2, key);
    plain_de = [plain_de plain_de_temp];
end
plain_de = [plain_de cipher_recover(i+64:length)];

Error_message_DES=plain(1,:)-plain_de(1,:);
save Error_CS_steg7_7_DES Error_message_DES;
nnz(Error_message_DES); % output = 0