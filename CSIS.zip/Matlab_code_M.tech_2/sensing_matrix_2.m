%%% measurement matrix using gradient descent optimization
s = sparse(20,1);
s(1,1)=10;s(2,1)=-5;s(5,1)=11;s(7,1)=14;s(11,1)=10;s(12,1)=10; % sparse vector
%%%%%%% sparse basis,.....let identity 
shi=eye(20);
% let initinal measuremenet matrix A as random matrix
D = rand(10,20);
[p,n] = size(D);
K=60;       % number of interation
step_size=0.02;     %step size
%%%%%% gradeint descent optimization
for k=1:K
    D  = normc(D);      %normaliza column of D
    D = D - step_size*D*(D'*D-eye(n));      % update D using Gradeint descentt algo
end
phi = D*shi';

s2_update=phi*s;            % only p measurements 
norm_s=norm(s,2);
norm_s2_update=norm(s2_update,2);  % approximately same as norm_s