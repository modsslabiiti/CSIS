%%%%%%%%%%%%% code as in paper "simulataneous learnig and sparsifying dictionary"
% simultaneous sensing and sparsifying matrix optimization
n=20; 
m=10;
s = sparse(n,1);
s(1,1)=10;s(2,1)=-5;s(5,1)=11;s(7,1)=14;s(11,1)=10;s(12,1)=10; % sparse vector
%%%%%%% sparse basis,.....let identity 
%shi=eye(20);
shi=dctmtx(n);
% let initinal measuremenet matrix A as random matrix
phi = rand(m,n);
%%% eihen decomposition of shi*shi'
[V,dg] = eig(shi*shi'); % dg diagonal matrix 
r = 0;      % number of nonzero eigen value of dg
for i=1:n
    if (dg(i,i)==0)
        r=r+1;
    end
end

Tau=phi*V;      % m x n
%U=Tau*dg;       % m x n
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:m               % total m vector of size n
    for j=1:n
        v(j,i)=dg(j,j)*Tau(i,j);
    end
end
% error matrices for each vector
 for j=1:m              % for total m vector
     E(:,:,j) = dg;
     for i=1:m
         if (i~=j)
           E(:,:,j) = E(:,:,j)- v(:,i)*v(:,i)';
         end
     end
     [U,edg]=eig(E(:,:,j));
     v(:,j)=sqrt(edg(1,1))*U(:,1);
 end
 Tau_update=Tau;
for i=1:r               % total m vector of size n
    for j=1:n
       Tau_update(i,j)=v(j,i)/dg(j,j);
    end
end
phi_update=Tau_update*V';
s2_update=phi_update*s;            % only p measurements 
norm_s=norm(s,2); 
norm_s2_update=norm(s2_update,2);  % approximately same as norm_s

