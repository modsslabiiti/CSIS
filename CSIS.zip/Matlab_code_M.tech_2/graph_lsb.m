clear all;
clc;
close all;
load fn_lsb;                     % write command 'save fn_lsb a ' 'a' is from lsb.m.m file
% b=unique(a(:));                    
%r=size(b,1);

c=zeros(256,1);
for i=1:256
    c(i)=i-1;
end
h1=hist(a(:),c);
figure(1),bar(c,h1),title('before lsb');

load fn_lsb2;                    % write command 'save fn_lsb2 modf_cover ' 'modf_cover' is from lsb.m file
c2=zeros(256,1);
for i=1:256
    c2(i)=i-1;
end
h2=hist(modf_cover(:),c2);
figure(2),bar(c2,h1),title('after lsb')

