a=[4 4 4 4 2 2 2 2 6 6 6 6 -2 -2 -2 -2 5 5 5 5 7 7 7 7];
a=int8(a);
b=a;
str1=[0 0 0 1 1 0 1 1 0 0 0 1 1 0 1 1 0 0 0 1 1 0 1 1 0 0 0 1 1 0 1 1 0 0 0 1 1 0 1 1 0 0 0 1 1 0 1 1];
k=1;
count=24;
for i=1:24                                      
        if a(1,i)==-1 || a(1,i)== 0 || a(1,i)==1
            continue;
        else
        if mod(a(1,i),2)==0
            if mod(a(1,i),4)==0
                if (k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==0
                    a(1,i)=a(1,i)+1;
                    k=k+2;   
                elseif((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==1)
                     a(1,i)=a(1,i)-1;
                    k=k+2;
                elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==0)
                     a(1,i)=a(1,i);
                    k=k+2;
                elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==1)
                     a(1,i)=a(1,i)+2;
                    k=k+2;
                end     
            else
                if((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==0)
                    if (a(1,i)~=2)
                        a(1,i)=a(1,i)-1;
                    else
                        a(1,i)=a(1,i)+3;
                    end
                    k=k+2;
                elseif((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==1)
                     if (a(1,i)~=-2)
                        a(1,i)=a(1,i)+1;
                    else
                        a(1,i)=a(1,i)-3;
                    end
                    k=k+2;
                elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==0)
                     if (a(1,i)~=-2)
                        a(1,i)=a(1,i)+2;
                    else
                        a(1,i)=a(1,i)-2;
                    end
                    k=k+2;
                elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==1)
                     a(1,i)=a(1,i);
                    k=k+2;
                end  
            end
        else
%             %if mod(aa(i,order_embed(1,j))-1,2)==0
                if mod(a(1,i)-1,4)==0
                    if((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==0)
                     a(1,i)=a(1,i);
                    k=k+2;   
                    elseif((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==1)
                     a(1,i)=a(1,i)-2;
                    k=k+2;
                    elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==0)
                     a(1,i)=a(1,i)-1;
                    k=k+2;
                    elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==1)
                    a(1,i)=a(1,i)+1;
                    k=k+2;
                    end     
                else
                     if((k+1)<count*2&&str1(1,k)==0&&str1(1,k+1)==0)
                     a(1,i)=a(1,i)+2;
                    k=k+2;
                    elseif((k+1)<(count*2)&&str1(1,k)==0&&str1(1,k+1)==1)
                     a(1,i)=a(1,i);
                    k=k+2;
                     elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==0)
                     a(1,i)=a(1,i)+1;
                    k=k+2;
                    elseif ((k+1)<count*2&&str1(1,k)==1&&str1(1,k+1)==1)
                     a(1,i)=a(1,i)-1;
                    k=k+2;
                    end  
                end          
                
            %end
        end
    end
 end

%%%%%%%%%%%%%%%%%%%%%%% Message recovery (extraction) check %%%%%%%%%%%%%%%%%%%%
str1_recover=zeros(1,count*2);
k2=1;
for i=1:24                                      
        if a(1,i)==-1 || a(1,i)== 0 || a(1,i)==1
            continue;
        else
            if mod(a(1,i),2)==0
              if mod(a(1,i),4)==0
                  str1_recover(1,k2)=1;
                  str1_recover(1,k2+1)=0;
                  k2=k2+2;
              else
                  str1_recover(1,k2)=1;
                  str1_recover(1,k2+1)=1;
                  k2=k2+2;
              end
            else
                %if mod(aa(i,order_embed(1,j))-1,2)==0
                 if mod(a(1,i)-1,4)==0
                    str1_recover(1,k2)=0;
                    str1_recover(1,k2+1)=0;
                    k2=k2+2;
                 else
                    str1_recover(1,k2)=0;
                    str1_recover(1,k2+1)=1;
                    k2=k2+2;
                 end
                %end
            end           
        end
end
Error_message=str1(1,:)-str1_recover(1,:);
