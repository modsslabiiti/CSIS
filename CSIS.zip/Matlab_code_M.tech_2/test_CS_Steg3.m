%%%%%% image compressed sensing using hadamard random measurement matrix
%%%%%% with selecting m according to coffecient of signal.solve by SpaRSA
clc;
clear;
close all;
clear all
clc;
path(path, 'D:\IIT INDORE\phd data\compressed sensing\matlab code\SpaRSA_2.0');
x=imread('boat.bmp');
figure,imshow(x),title('Original Image');

blk=8; % image is decomposed using 8x8 blocks

[row col]=size(x);
%order=[1 9 2 3 10 17 25 18 11 4 5 12 19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];

%order=[33 41 49 57 26 34 42 50 19 27 35 43 12 20 28 36 5 13 21 29 6 14 22 7 15 8];

fun1=@dct2;
fun2=@idct2;
% block wise sparsification 
J = blkproc(x,[blk blk],fun1);
x1=im2col(J,[blk blk],'distinct');  % taking blk x blk matrix as column.....
% x1=x1'; 
n=blk*blk;
%m=n/4;      % numner of measurements
A = hadamard(n);
%A_normalize=normc(A);

% index for measurement matrix
%{
for i=1:blk/2           %for m=n/4
    for j=1:blk/2
        index(j+(i-1)*blk/2)=j+(i-1)*blk;
    end
end
%}
index=[1 9 2 3 10 17 25 18 11 4 5 12 19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8];
m=size(index);
%%%%% updating measurement matrix
A2=A(index,:);      % size m x n (m<n)
A2_normalize=normc(A2);

%%%% fiinding measurements y=A*x
for i=1:(row*col)/(blk*blk)
    y(:,i)=A2_normalize*x1(:,i);
end

%%%%%%%% perform OMP%%%%%%%
%%% let sparsity is K 
K=n/2;
for i=1:(row*col)/(blk*blk)
    y_temp=y(:,i);
    tau=0.5;
    [x_temp,x_debias,objective,times,debias_start,mses,taus]= SpaRSA(y_temp,A2_normalize,tau);
    %[x_temp]= OMP (A2_normalize,y_temp,K);
    x_update(:,i)=x_temp;
end
%%%%%%%%%%%%%%%%%Image generation
x2=col2im(x_update,[blk blk],[row col],'distinct');
            x_reconstrcut=uint8(blkproc(x2,[blk blk],fun2));
            save fn3 x_reconstrcut;
psnr(x,x_reconstrcut,255);
figure,imshow(x_reconstrcut);
imwrite(x_reconstrcut,'x_reconstrcut_boat.jpeg');
figure,imhist(x);
figure,imhist(x_reconstrcut);
