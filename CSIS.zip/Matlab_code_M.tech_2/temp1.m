%%%%%%% hadamard tronsform and image processing
I=double(imread('lena.bmp'));
[m n]=size(I);
blk=4;
fun1=@fwht;
fun2=@ifwht;  
J = blkproc(I,[blk blk],fun1);

for i=1:m
    chk=rem(i,blk);
    if (chk==1)
        J(i,:)=J(i,:);
    else
        J(i,:)=rand(1,1);
    end
    
end
I_compressed=uint8(blkproc(J,[blk blk],fun2));
I_original=imread('lena.bmp');
psnr=psnr(I_original,I_compressed,255);