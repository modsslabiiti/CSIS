clear all;
clc;
close all;

load fn1; % load 'a' the original transfrom coefficients
load fn2;  % % load 'aaa' the modified transfrom coefficients
c2=zeros(256,1);
for i=0:255
    c2(i+1)=i;
end

hist(double(a.'), unique(double(a(:))));
hist(double(aaa.'), unique(double(aaa(:))));
