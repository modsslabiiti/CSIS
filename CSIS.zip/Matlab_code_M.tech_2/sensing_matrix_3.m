% simultaneous sensing and sparsifying matrix optimization (
% measurement matrix using gradient descent optimization and eigrn
%%% decomposition  of sparsifying matrix )
n=20; 
m=10;
s = sparse(n,1);
s(1,1)=10;s(2,1)=-5;s(5,1)=11;s(7,1)=14;s(11,1)=10;s(12,1)=10; % sparse vector
%%%%%%% sparse basis,.....let identity 
%shi=eye(20);
shi=dctmtx(n);
% let initinal measuremenet matrix A as random matrix
phi = rand(m,n);
%%% eihen decomposition of shi*shi'
[V,dg] = eig(shi*shi'); % dg diagonal matrix 
Tau=phi*V;
U=Tau*dg;
%%%%%%% now find U which minimize ||U*U'-dg||^2 2-norm

K=60;       % number of interation
step_size=0.02;     %step size
%%%%%% gradeint descent optimization
for k=1:K
    U  = normc(U);      %normaliza column of D
    U = U - step_size*U*(U'*U-normc(dg));      % update D using Gradeint descentt algo
end
Tau=U*inv(dg);
phi =Tau*inv(V);%% or phi=Tau*V'
s2_update=phi*s;            % only p measurements 
norm_s=norm(s,2); 
norm_s2_update=norm(s2_update,2);  % approximately same as norm_s

%%%%%%%%%%%%% code as in paper "simulataneous learnig and sparsifying dictionary"

%%% error
E=dg-U;