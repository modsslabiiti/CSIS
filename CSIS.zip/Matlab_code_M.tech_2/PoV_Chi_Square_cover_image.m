clear all;
clc;
close all;

cover = input('Enter cover image: ', 's');
a=imread(cover);
%a=imread('boat.bmp');
c2=zeros(256,1);
for i=0:255
    c2(i+1)=i;
end
[L M]=size(a);
DF=[128 128 128 128 128 128 128 128 128 128];       
for er=1:10
    pt1=floor(0.1*er*L);
    pt2=floor(0.1*er*M);
    a_1=a(1:pt1,1:pt2);
    h1=hist(a_1(:),c2);
    X=zeros(128,1);         % frequency of pixel 2k
    Y=zeros(128,1);         % frequency of pixel 2k+1
    for i=1:128
        X(i)=h1(1,2*i-1);      %%%%Even ........ %h1(1,1)    contain pixel 0's frequency 
        Y(i)=h1(1,2*i);
    end
     Z=zeros(128,1);         % expected frequency pixel 2k of gray scale image
    for i=1:128
        if (X(i)+Y(i)<=4)
            X(i)=0;
            Y(i)=0;
            DF(1,er)=DF(1,er)-1;
        end
        Z(i)=(X(i)+Y(i))/2;
    end
    Xn(1,er)=0;
    for i=1:128
         if Z(i)==0
            continue;
         else
        Xn(1,er)=Xn(1,er)+((X(i)-Z(i))*(X(i)-Z(i))/Z(i));       % chi square statics
         end
    end
   diff=zeros(128,1);         % difference of even and odd pixel value frequency
    for i=1:128
     %   diff(i)=abs(X(i)-Y(i));     % % Even odd frequency difference
    end
   % figure,plot(1:128,diff);
 
%     figure
%     subplot(2,1,1)       % add first plot in 2 x 1 grid
%     plot(X,1:128)
%     title('Odd pixel value frequency')
% 
%     subplot(2,1,2)       % add second plot in 2 x 1 grid
%     plot(Y,1:128','+')       % plot using markers
%     title('Even pixel value frequency')
%     %%%% Probability of embedding.........see chi-square attack
%     q1=1/(power(2,63.5));        % 255/2 = 127... (127-1/2) = 63
%     q2=1/gamma(63.5);           
%     fun = @(u) exp(-u/2).*power(u,62.5)*q1*q2;   % chi square probability function
%      q = integral(fun,0,Xn);
%      q3=(1-q);       % probability of embedding
%     q4(er)=q3*100;         % probability of embedding in percentage

 %%%%%%%%%%%%% Chi-square test %%%%%%%%%%%%%%%%%%%%%%%%%
 F(1,er) = pchisq(Xn(1,er),DF(1,er)-1);       % must have pchisq.m
 P(1,er)=100*(1-F(1,er));             % probability of embedding 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
plot(P,1:10);