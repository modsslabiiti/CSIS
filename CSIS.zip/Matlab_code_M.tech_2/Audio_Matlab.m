[f,fs] = audioread('arctic_a0004.wav');
%f would be the signal read into MATLAB while fs is the sampling frequency of your signal. 
%f here is a 2D matrix. The first column is the left channel while the second is the right channel. 
%In general, the total number of channels in your audio file is denoted by the total number of columns in this 
%matrix read in through audioread.
%% Plot both audio channels
N = size(f,1); % Determine total number of samples in audio file
figure;
subplot(2,1,1);
stem(1:N, f(:,1));
title('Left Channel');
%% Plot the spectrum
df = fs / N;
w = (-(N/2):(N/2)-1)*df;  % N/2 is the maximum frequency component (Nyquist theorem)
y = fft(f(:,1), N) / N; % For normalizing, but not needed for our analysis
y2 = fftshift(y);
figure;
plot(w,abs(y2));
