% fast discreate walsh hadamard transform sparsification and compressed
% sensing using hadamard sensing matrix
clc;
clear;
close all;
clear all
clc;
path(path, 'D:\IIT INDORE\phd data\matlab-toolboxes-master\toolbox_sparsity');
path(path, 'D:\IIT INDORE\phd data\compressed sensing\matlab code\CoSaMP_OMP');
I=imread('lena.bmp');
SI=imread('boat.bmp');
[n1,n2]=size(I);
[m1,m2]=size(SI);
figure,imshow(I),title('Original Image');
blk=8; % image is decomposed using 8x8 blocks
order=[1 9 2 3 10 17 25 18 11 4 5 12 19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];
order_not_embed = [1 9 2 3 10 17 25 18 11 4]; % taking 10 coeffieints which as taken as these are
order_can_embed = [5 12 19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];
%order1=[33 41 49 57 26 34 42 50 19 27 35 43 12 20 28 36 5 13 21 29 6 14 22 7 15 8];
skip_cof=1;
cof_max_min=2;
embed_cof=12;  %k1=size(order_not_embed); 
        %k1=k1(2);
        %k2=size(order_can_embed);
embed_not_cof= blk*blk - embed_cof - skip_cof - cof_max_min; %%k2=k2(2);
fun1=@dct2;
fun2=@idct2;
% block wise sparsification 
I1 = blkproc(I,[blk blk],fun1);
I2=im2col(I1,[blk blk],'distinct');  % taking blk x blk matrix as column.....
I2_zig=I2(order,:);
I2_embed_image = I2(1:(skip_cof + embed_cof + cof_max_min),:); %%or I2_not_embed = I2(order_not_embed,:);
I2_embed_message = I2(skip_cof + embed_cof + cof_max_min + 1:embed_not_cof + skip_cof + embed_cof + cof_max_min,:); %% or I2_can_embed = I2(order_can_embed,:);

%%%%%%%% for secret image %%%%%%%%
SI1 = blkproc(SI,[blk blk],fun1);
SI2=im2col(SI1,[blk blk],'distinct');  % taking blk x blk matrix as column.....
SI2_zig=SI2(order,:);
SI2_embed_cof=SI2(1:embed_cof,:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
no_block=size(I2,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%embedding%%%%%%%%%%%%
% Embedding of secret image's coefficients----------
for i=1:no_block
    I2_embed_image(skip_cof+1,i)= I2_embed_image(skip_cof,i)+ 0.0001*SI2_embed_cof(1,i);
    max_c=max(I2_embed_image(skip_cof+cof_max_min:embed_cof+skip_cof+cof_max_min,i));
    min_c=min(I2_embed_image(skip_cof+cof_max_min:embed_cof+skip_cof+cof_max_min,i));
    I2_embed_image(skip_cof+cof_max_min,i)=max_c;
    I2_embed_image(embed_cof+skip_cof+cof_max_min,i)=min_c;
    t1=skip_cof+cof_max_min+1;      
    t2=embed_cof+skip_cof+cof_max_min-1;
    I2_embed_image(t1:t2,i)=(SI2_embed_cof(2:embed_cof,i)-min_c)/(max_c-min_c);
end
k2=blk*blk - embed_cof - skip_cof - cof_max_min;
n=k2;
%A = hadamard(n);    % for hadamard n must be an integer and n, n/12 or n/20 must be a power of 2.
A = hadamard(blk*blk);
%A=rand(blk*blk);
p = randperm(blk*blk,n);
A = A(:,p);
m=round(n/2);
%A_normalize=normc(A);
%%%%% taking first 24 rows (we have already taken image block in zig zag scanning ordeer
A2 = A(1:m,:);      %n/2=24;
A2_normalize=normc(A2);
A2_normalize=A2;
%%%% fiinding measurements y=A*x
for i=1:(n1*n2)/(blk*blk)
    I3(:,i)=A2_normalize*I2_embed_message(:,i);
end
% cobmined coefficients which embeded message coefficients and message coefficientd
I4 = zeros(skip_cof + embed_cof + cof_max_min + m, (n1*n2)/(blk*blk)); % 8 is size of order_not_embed
%y_update(order_not_embed,:)=x1(order_not_embed,:);
I4 = [I2_embed_image; I3];   % row wise concatenate..... coefficients 
%%%%%%%%%%% RECOVER SECRET IMAGE %%%%%%%%%%%%%
SI_Recover=zeros(blk*blk,no_block);
for i=1:no_block
    SI_Recover(1,i) = (I4(skip_cof+1,i)-I4(skip_cof,i))/0.0001;
    max_c1=I4(skip_cof+cof_max_min,i);
    min_c1=I4(embed_cof+skip_cof+cof_max_min,i);
    t3=skip_cof+cof_max_min+1;      
    t4=embed_cof+skip_cof+cof_max_min-1;
    SI_Recover(2:12,i) = min_c1+(max_c1-min_c1)*I4(t3:t4,i); 
end
SI_Recover_2=col2im(SI_Recover,[blk blk],[m1 m2],'distinct');
Recover_SI=uint8(blkproc(SI_Recover_2,[blk blk],fun2));
psnr1 = psnr(SI,Recover_SI,255);
figure,imshow(Recover_SI),title('Secret Image recovered');
%imhist(DCTcompressed);
figure,imhist(SI);
figure,imhist(Recover_SI);
%%%% Recover cover image %%%%%
I_Recover = zeros(blk*blk,no_block);


% Recovery
options.tol = 1e-3;  % tolerance
options.nbr_max_atoms = m;  %%options.nbr_max_atoms = 200;
%options.nbr_max_atoms = m/2;  %%options.nbr_max_atoms = k;
 tic
 options.use_slow_code = 0;
for i=1:(n1*n2)/(blk*blk)
    %I1_measurements_temp=I1_measurements(:,i)';
    I3_temp=I3(:,i);
   % x0=h1'*I1_measurements_temp;
%I1_sparse_recons_temp=l1eq_pd(x0,h1,[],I1_measurements_temp,1e-5);
%I1_sparse_recons_temp=OMP(m,I1_measurements_temp,h1);
I3_sparse_recons_temp=perform_omp(A2_normalize,I3_temp,options);
%I1_sparse_recons(:,i)=I1_sparse_recons_temp';
I3_sparse_recons(:,i)=I3_sparse_recons_temp;
end
toc
I4_recons = [I2_embed_image; I3_sparse_recons];
for i=1:n2
   I1_recons(:,i)=ifwht(I1_sparse_recons(:,i));
end
Err1=I1-I1_recons; 
I_recons=uint8(I1_recons);%%%I_recons=im2uint8(I1_recons);
Err2=I-I_recons;

